let map = {
    '1-1': 'questionnaire/DietaryhabitsSouth',
    '1-2': 'questionnaire/Schoolwork'
};
export default map;